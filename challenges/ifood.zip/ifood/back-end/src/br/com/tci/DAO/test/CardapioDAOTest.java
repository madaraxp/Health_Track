package br.com.tci.DAO.test;

import java.util.List;

import br.com.tci.DAO.CardapioDAO;

public class CardapioDAOTest {

	public static void main(String[] args) {
		
		CardapioDAO cardapioDAO = new CardapioDAO();		
	}

}
