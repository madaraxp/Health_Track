package br.com.tci.DAO.test;

import java.util.ArrayList;

import br.com.tci.Atendimento;
import br.com.tci.DAO.AtendimentoDAO;
import br.com.tci.DAO.EmpresaDAO;

public class AtendimentoDAOTest {

	public static void main(String[] args) {

//		AtendimentoDAO atendimentoDAO = new AtendimentoDAO();
//		EmpresaDAO empresaDAO = new EmpresaDAO();
//
//		var empresaDatabase = empresaDAO.Get(1);
//
//		Atendimento atendimento = new Atendimento("08:00 - 17:00", "08:00 - 17:00", "08:00 - 17:00", "08:00 - 17:00",
//				"08:00 - 22:00", "08:00 - 22:00", "08:00 - 16:00", "08:00 - 16:00", empresaDatabase);
//
//		// Insert
//		atendimentoDAO.Insert(atendimento);
	}
}
