package br.com.tci.DAO;

public class EnderecoDAO {

}
