package br.com.tci.DAO;

public class EmpresaCategoria {

}
