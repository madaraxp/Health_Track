package br.com.tci.DAO.test;

public class DashboardDAOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
